﻿using System.ComponentModel.DataAnnotations;

namespace Dumbahh_calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a whole number to calculate the sum, product and amount of it's digits");
            int n = int.Parse(Console.ReadLine());
            int digit_amnt = n.ToString().Length;
            int sum = 0;
            int product = 0;

            if (n != 0)
            {
                product = 1;
                for (int i = 0; i < digit_amnt; i++)
                {
                    sum += n % 10;
                    product *= n % 10;
                    n = n / 10;

                }
            }
            

            Console.WriteLine($"The number of digits is: {digit_amnt}");
            Console.WriteLine($"The sum of digits is: {sum}");
            Console.WriteLine($"The product of digits is: {product}");



        }
    }
}
